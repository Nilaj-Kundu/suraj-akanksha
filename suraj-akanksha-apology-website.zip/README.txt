# Suraj → Akanksha apology website

Open `index.html` locally to preview it.

## Put it online for free with GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html` and the `assets` folder.
3. In GitHub: Settings → Pages → deploy from the `main` branch.
4. GitHub will give you the shareable website link.

The two supplied photos are already included in `assets/`.
